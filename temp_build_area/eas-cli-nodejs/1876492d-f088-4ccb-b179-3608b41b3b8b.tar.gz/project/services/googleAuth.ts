// services/googleAuth.ts
import { GoogleSignin, statusCodes } from '@react-native-google-signin/google-signin';
import apiClient, { apiService } from './api';

// Firebase Console'dan alınan Web Client ID (google-services.json içindeki client_type: 3 olan)
const WEB_CLIENT_ID = '850829107432-0tm2phdo4hcmjkv251bsjcgni3s174id.apps.googleusercontent.com';

export const googleAuthService = {
    configure: () => {
        GoogleSignin.configure({
            webClientId: WEB_CLIENT_ID,
            offlineAccess: true, // Refresh token alabilmek için
            scopes: ['profile', 'email'],
        });
    },

    signIn: async (userType?: 'CITIZEN' | 'ELECTRICIAN', serviceCategory?: string) => {
        try {
            // Google Play Services kontrolü
            await GoogleSignin.hasPlayServices();

            // Google ile giriş yap
            const userInfo = await GoogleSignin.signIn();
            const { idToken } = userInfo;

            if (!idToken) {
                throw new Error('Google ID Token alınamadı');
            }

            console.log('Google Sign-In Success:', { email: userInfo.user.email });

            // Backend'e gönder
            const response = await apiClient.post('/auth/google', {
                token: idToken,
                userType, // Send userType if provided (Register intent)
                serviceCategory, // Send serviceCategory if provided
            });

            // Tokenları kaydet
            const authData = response.data.data;
            await apiService.setTokens(authData.accessToken, authData.refreshToken);

            return authData;

        } catch (error: any) {
            if (error.code === statusCodes.SIGN_IN_CANCELLED) {
                // Kullanıcı iptal etti - sessizce dön
                throw new Error('CANCELLED');
            } else if (error.code === statusCodes.IN_PROGRESS) {
                throw new Error('Giriş işlemi zaten devam ediyor');
            } else if (error.code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE) {
                throw new Error('Google Play Hizmetleri kullanılamıyor');
            } else {
                console.error('Google Sign-In Error:', error);
                throw error;
            }
        }
    },

    signOut: async () => {
        try {
            await GoogleSignin.signOut();
        } catch (error) {
            console.error('Google Sign-Out Error:', error);
        }
    },

    isSignedIn: async () => {
        const isSignedIn = await GoogleSignin.isSignedIn();
        return isSignedIn;
    }
};
